module.exports = function(){
    var express = require('express');
    var router = express.Router();

    

    function getBorrowing(res, mysql, context, complete){
        mysql.pool.query("SELECT * from borrowing", function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }
            context.borrowing = results;
            complete();
        });
    }



function getABorrowing(res, mysql, context, id, complete){
        var sql = "SELECT * from borrowing WHERE id = ?";
        var inserts = [id];
        mysql.pool.query(sql, inserts, function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }
            context.aborrowing = results[0];          // for updating a single book-borrowing details.
            complete();
        });
    }
     

   
    /*Display all borrowing details. Requires web based javascript to delete users with AJAX*/

    router.get('/', function(req, res){
        var callbackCount = 0;
        var context = {};
        context.jsscripts = ["deleteborrowing.js"];
        var mysql = req.app.get('mysql');
        getBorrowing(res, mysql, context, complete);
        function complete(){
            callbackCount++;
            if(callbackCount >= 1){
                res.render('borrowing', context);
            }

        }
    });



     /* Display one borrowing details for the specific purpose of updating borrowing details. */

    router.get('/:id', function(req, res){
        callbackCount = 0;
        var context = {};
        context.jsscripts = ["updateborrowing.js"];
        var mysql = req.app.get('mysql');
        getABorrowing(res, mysql, context, req.params.id, complete);
        
        function complete(){
            callbackCount++;
            if(callbackCount >= 1){
                res.render('update-borrowing', context);
            }

        }
    });


 /* The URI that update data is sent to in order to update a borrowing details */

    router.put('/:id', function(req, res){
        var mysql = req.app.get('mysql');
        console.log(req.body)
        console.log(req.params.id)

        //book_id , patron_id , date_checked , date_returned
        var sql = "UPDATE borrowing SET book_id=?, patron_id=?, date_checked=?, date_returned=? WHERE id=?";
        var inserts = [req.body.book_id, req.body.patron_id, req.body.date_checked, req.body.date_returned, req.params.id];
        sql = mysql.pool.query(sql,inserts,function(error, results, fields){
            if(error){
                console.log(error)
                res.write(JSON.stringify(error));
                res.end();
            }else{
                res.status(200);
                res.end();
            }
        });
    });

    /* Route to delete a borrowing details, simply returns a 202 upon success. Ajax will handle this. */

    router.delete('/:id', function(req, res){
        var mysql = req.app.get('mysql');
        var sql = "DELETE FROM borrowing WHERE id = ?";
        var inserts = [req.params.id];
        sql = mysql.pool.query(sql, inserts, function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.status(400);
                res.end();
            }else{
                res.status(202).end();
            }
        })
    })
   

   

    /* Adds a borrowing details, redirects to the borrowing page after adding */

    router.post('/', function(req, res){
        
        console.log(req.body)
        var mysql = req.app.get('mysql');
        var sql = "INSERT INTO borrowing (book_id , patron_id , date_checked , date_returned ) VALUES (?, ?, ?, ?)"
        var inserts = [req.body.book_id, req.body.patron_id,req.body.date_checked,req.body.date_returned];
        sql = mysql.pool.query(sql,inserts,function(error, results, fields){
            if(error){
                console.log(JSON.stringify(error))
                res.write(JSON.stringify(error));
                res.end();
            }else{
                res.redirect('/borrowing');
            }
        });
    });

    
    return router;
}();