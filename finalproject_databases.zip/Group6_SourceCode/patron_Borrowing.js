module.exports = function(){
    var express = require('express');
    var router = express.Router();


function getPatronsWithB(res, mysql, context, complete){
        mysql.pool.query("SELECT p.id, firstname , lastname , title , date_checked ,date_returned FROM patrons  p INNER JOIN borrowing bg ON p.id = bg.patron_id INNER JOIN books b ON b.id = bg.book_id ", function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }
            context.p_borrowing = results;
            complete();
        });
    }




  function getPatronsWithBooks(req, res, mysql, context, complete) {
      //sanitize the input as well as include the % character
       var query = "SELECT p.id, firstname , lastname , title , date_checked ,date_returned FROM patrons  p INNER JOIN borrowing bg ON p.id = bg.patron_id INNER JOIN books b ON b.id = bg.book_id WHERE p.firstname LIKE " + mysql.pool.escape(req.params.s + '%');
      console.log(query)

      mysql.pool.query(query, function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }
            context.p_borrowing = results;
            complete();
        });
    }



router.get('/', function(req, res){
        var callbackCount = 0;
        var context = {};
        context.jsscripts = ["searchp_Borrowing.js"];
        var mysql = req.app.get('mysql');
        getPatronsWithB(res, mysql, context, complete);
        function complete(){
            callbackCount++;
            if(callbackCount >= 1){
                res.render('patron_Borrowing', context);
            }

        }
    });



/*Display all patrons with book borrowing detail and book title whose patron starts with a given string. Requires web based javascript to delete and search patrons with AJAX */
 router.get('/search/:s', function(req, res){
        console.log("==url params for req:", req.params);
   var callbackCount = 0;
        var context = {};
        context.jsscripts = ["searchp_Borrowing.js"];
        var mysql = req.app.get('mysql');
        getPatronsWithBooks(req, res, mysql, context, complete);
        function complete(){
            callbackCount++;
            if(callbackCount >= 1){
                res.render('patron_Borrowing', context);
            }
        }
    });
  return router;
}();

