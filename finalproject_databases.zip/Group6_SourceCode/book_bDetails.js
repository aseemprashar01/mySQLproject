module.exports = function(){
    var express = require('express');
    var router = express.Router();


function getBooksWithTitleQ(res, mysql, context, complete){
        mysql.pool.query("SELECT id, title , author , publisher , ISBN ,quantity FROM books  b INNER JOIN bookdetails bd ON b.id = bd.book_id", function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }
            context.book_bdetail = results;
            complete();
        });
    }




  function getBooksWithQty(req, res, mysql, context, complete) {
      //sanitize the input as well as include the % character
       var query = "SELECT id, title , author , publisher , ISBN , quantity FROM books b INNER JOIN bookdetails bd ON b.id = bd.book_id WHERE b.title LIKE " + mysql.pool.escape(req.params.s + '%');
      console.log(query)

      mysql.pool.query(query, function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }
            context.book_bdetail = results;
            complete();
        });
    }

/*Display all books joined with book-details. Requires web based javascript to delete users with AJAX*/

router.get('/', function(req, res){
        var callbackCount = 0;
        var context = {};
        context.jsscripts = ["searchb_bdetails.js"];
        var mysql = req.app.get('mysql');
        getBooksWithTitleQ(res, mysql, context, complete);
        function complete(){
            callbackCount++;
            if(callbackCount >= 1){
                res.render('book_bDetails', context);
            }

        }
    });

/*Display all books with bookdetails whose title starts with a given string. Requires web based javascript to delete users with AJAX */
 router.get('/search/:s', function(req, res){
        console.log("==url params for req:", req.params);
   var callbackCount = 0;
        var context = {};
        context.jsscripts = ["searchb_bdetails.js"];
        var mysql = req.app.get('mysql');
        getBooksWithQty(req, res, mysql, context, complete);
        function complete(){
            callbackCount++;
            if(callbackCount >= 1){
                res.render('book_bDetails', context);
            }
        }
    });
  return router;
}();
