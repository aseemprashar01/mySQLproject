module.exports = function(){
    var express = require('express');
    var router = express.Router();

    

    function getLocation(res, mysql, context, complete){
        mysql.pool.query("SELECT id , row , shelf from location", function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }
            context.location = results;
            complete();
        });
    }



   
    /*Display all book-locations. */

    router.get('/', function(req, res){
        var callbackCount = 0;
        var context = {};
        //context.jsscripts = ["deletebook.js"];
        var mysql = req.app.get('mysql');
        getLocation(res, mysql, context, complete);
        function complete(){
            callbackCount++;
            if(callbackCount >= 1){
                res.render('location', context);
            }

        }
    });

   

   

    /* Adds a book-details, redirects to the people page after adding */

    router.post('/', function(req, res){
        
        console.log(req.body)
        var mysql = req.app.get('mysql');
        var sql = "INSERT INTO location (row , shelf) VALUES (?, ?)"
        var inserts = [req.body.row, req.body.shelf];
        sql = mysql.pool.query(sql,inserts,function(error, results, fields){
            if(error){
                console.log(JSON.stringify(error))
                res.write(JSON.stringify(error));
                res.end();
            }else{
                res.redirect('/location');
            }
        });
    });

    
    return router;
}();
