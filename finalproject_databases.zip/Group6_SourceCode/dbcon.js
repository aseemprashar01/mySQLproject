var mysql = require('mysql');
var pool = mysql.createPool({
  connectionLimit : 10,
  host            : 'classmysql.engr.oregonstate.edu',
  user            : 'cs340_prashara',
  password        : '2750',
  database        : 'cs340_prashara'
});
module.exports.pool = pool;
