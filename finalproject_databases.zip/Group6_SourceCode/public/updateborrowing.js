function updateBorrowing(id){
    $.ajax({
        url: '/borrowing/' + id,
        type: 'PUT',
        data: $('#update-borrowing').serialize(),
        success: function(result){
            window.location.replace("./");
        }
    })
};
