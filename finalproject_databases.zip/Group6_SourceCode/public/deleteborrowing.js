function deleteBorrowing(id){
    $.ajax({
        url: '/borrowing/' + id,
        type: 'DELETE',
        success: function(result){
            window.location.reload(true);
        }
    })
};
