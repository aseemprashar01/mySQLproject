function searchBookByTitle() {
    //get the first name 
    var book_title_string  = document.getElementById('book_title_string').value
    //construct the URL and redirect to it
    window.location = '/books/search/' + encodeURI(book_title_string)
}
