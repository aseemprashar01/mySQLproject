function searchBookByTitleQ() {
    //get the first name 
    var book_title_string  = document.getElementById('book_title_string').value
    //construct the URL and redirect to it
    window.location = '/book_bDetails/search/' + encodeURI(book_title_string)
}
