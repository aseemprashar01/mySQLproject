function searchPatronsByFnameBooks() {
    //get the first name 
    var patron_fname_string  = document.getElementById('patron_fname_string').value
    //construct the URL and redirect to it
    window.location = '/patron_Borrowing/search/' + encodeURI(patron_fname_string)
}